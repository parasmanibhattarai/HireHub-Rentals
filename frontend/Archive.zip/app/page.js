import { HomeLanding } from "@/components/home";

export default function Home() {
  return <HomeLanding />;
}
